#define UTS_RELEASE "2.6.32-1-jolicloud-atom"
