#define UTS_RELEASE "2.6.32-4-jolicloud"
