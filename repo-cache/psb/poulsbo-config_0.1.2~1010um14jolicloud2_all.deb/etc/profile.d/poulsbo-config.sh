# Activate GMA500 support in vaapi
export GMA500_WORKAROUND=yes
