#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 3
#define VBOX_VERSION_MINOR 1
#define VBOX_VERSION_BUILD 6
#define VBOX_VERSION_STRING "3.1.6_OSE"

#endif
